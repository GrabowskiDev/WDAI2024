import './Shapes.css';

function Rectangle() {
	return (
		<div className="rectangle">
			<p>rectangle</p>
		</div>
	);
}

export default Rectangle;
