import './Shapes.css';

function Square() {
	return (
		<div className="square">
			<p>square</p>
		</div>
	);
}

export default Square;
