import './Shapes.css';

function Circle() {
	return (
		<div className="circle">
			<p>circle</p>
		</div>
	);
}

export default Circle;
