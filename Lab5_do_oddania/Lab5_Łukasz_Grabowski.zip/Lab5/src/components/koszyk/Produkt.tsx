function Produkt(props: { name: string }) {
	return (
		<>
			<h2>{props.name}</h2>
		</>
	);
}

export default Produkt;
