export interface ArticleInterface {
	id: number;
	title: string;
	content: string;
}
